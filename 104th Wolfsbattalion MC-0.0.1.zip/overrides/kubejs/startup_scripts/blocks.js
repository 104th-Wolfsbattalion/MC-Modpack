StartupEvents.registry('block', event => {

	event.create('completionist_cup').displayName('Completionist Cup').defaultCutout()
});
