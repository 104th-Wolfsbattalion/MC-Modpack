REIEvents.removeCategories((event) => {
    
    event.remove('minecraft:plugins/tag')
  })