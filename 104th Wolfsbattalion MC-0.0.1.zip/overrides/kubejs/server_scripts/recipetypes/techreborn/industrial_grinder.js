////////////////////////
/// Made by Team AOF ///
////////////////////////


ServerEvents.recipes(event => {

event.custom({    
  "type": "techreborn:industrial_grinder",
  "power": 128,
  "time": 100,
  "tank": {
    "fluid": "minecraft:water",
    "amount": 1000
  },
  "ingredients": [
	{
	  "tag": "c:certus_quartz"
	}
  ],
  "results": [
	{
	  "item": "ae2:certus_quartz_dust"
	}
  ]
})
    })