////////////////////////
/// Made by Team AOF ///
////////////////////////


ServerEvents.recipes(event => {

  
    event.custom({    
      "type": "techreborn:centrifuge",
      "power": 16,
      "time": 600,
      "ingredients": [
        {
          "tag": "c:coal_dusts"
        }
      ],
      "results": [
        {
          "item": "modern_industrialization:carbon_dust"
        }
      ]
})
    })