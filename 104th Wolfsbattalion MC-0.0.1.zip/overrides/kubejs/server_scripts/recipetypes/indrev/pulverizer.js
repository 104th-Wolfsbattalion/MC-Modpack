////////////////////////
/// Made by Team AOF ///
////////////////////////


ServerEvents.recipes(event => {


    // Quartz
    event.recipes.indrev.pulverize({

        type: "indrev:pulverize",
        ingredients: {
            tag: 'c:certus_quartz',
            count: 1
        },
        output: {
            item: 'ae2:certus_quartz_dust',
            count: 1
        },
        processTime: 300

    });

    // Fluix
    event.recipes.indrev.pulverize({

        type: "indrev:pulverize",
        ingredients: {
            tag: 'c:fluix',
            count: 1
        },
        output: {
            item: 'ae2:fluix_dust',
            count: 1
        },
        processTime: 300

    });

    // Coke
    event.recipes.indrev.pulverize({

        type: "indrev:pulverize",
        ingredients: {

            item: 'modern_industrialization:coke',
            count: 1
        },
        output: {
            item: 'modern_industrialization:coke_dust',
            count: 1
        },
        processTime: 300

    });

    // Prosperity Shards
    event.recipes.indrev.pulverize({

        type: "indrev:pulverize",
        ingredients: {

            tag: 'c:prosperity_ores',
            count: 1
        },
        output: {
            item: 'mysticalagriculture:prosperity_shard',
            count: 2
        },
        processTime: 300

    });

    const mi_raw = [
        "tungsten",
        "antimony",
        "nickel",
        "iridium"
    ];

    mi_raw.forEach((item) => {
        event.recipes.indrev.pulverize({

            type: "indrev:pulverize",
            ingredients: {

                item: 'modern_industrialization:raw_' + item,
                count: 2
            },
            output: {
                item: 'modern_industrialization:' + item + '_dust',
                count: 3
            },
            processTime: 300

        });
    });

    const mi_ores = [
        "antimony",
        "iridium",
        "lead",
        "nickel",
        "silver",
        "tin",
        "tungsten"
    ];

    const mi_ores_2 = [
        "platinum",
        "titanium",
    ];

    mi_ores.forEach((item) => {
        event.recipes.indrev.pulverize({

            type: "indrev:pulverize",
            ingredients: {

                tag: 'c:' + item + '_ores',
                count: 1
            },
            output: {
                item: 'modern_industrialization:raw_' + item,
                count: 2
            },
            processTime: 300
        });
    });

    mi_ores_2.forEach((item) => {
        event.recipes.indrev.pulverize({

            type: "indrev:pulverize",
            ingredients: {

                item: 'modern_industrialization:' + item + '_ore',
                count: 1
            },
            output: {
                item: 'modern_industrialization:raw_' + item,
                count: 2
            },
            processTime: 300
        });
    });

    // Mythic Metals
    const mythicmetals = [
        'adamantite',
        'aquarium',
        'banglum',
        'carmot',
        'kyber',
        'morkite',
        'mythril',
        'orichalcum',
        'osmium',
        'palladium',
        'prometheum',
        'quadrillum',
        'runite',
        'starrite',
        'stormyx'
    ];

    mythicmetals.forEach((item) => {
        event.recipes.indrev.pulverize({

            type: "indrev:pulverize",
            ingredients: {

                tag: "c:" + item + "_ores",
                count: 1
            },
            output: {
                item: "mythicmetals:raw_" + item,
                count: 2
            },
            processTime: 300

        });
    });
});
